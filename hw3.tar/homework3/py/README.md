Compiling protobufs:
`./compile_protobuf.sh`

Running server:
`./globesort_server.py <server_port>`

Running client:
`./globesort_client.py <server_ip> <server_port> <values>`
